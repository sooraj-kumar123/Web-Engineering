import React, { useState } from 'react';

const App = () => {
  const [tasks, setTasks] = useState({
    BackLog: [],
    InProgress: [],
    Completed: []
  });
  const [taskInput, setTaskInput] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('BackLog');

  const handleAddTask = () => {
    setTasks({
      ...tasks,
      [selectedCategory]: [...tasks[selectedCategory], taskInput]
    });
    setTaskInput('');
  };

  const handleDeleteTask = (category, index) => {
    const updatedTasks = { ...tasks };
    updatedTasks[category].splice(index, 1);
    setTasks(updatedTasks);
  };

  return (
    <div className='my_div1'>
      <h1 className='heading'>ToDoList - Task</h1>
      <div className='my_div2'>
        <input
          className='InputField'
          type='text'
          placeholder='Enter Task'
          value={taskInput}
          onChange={(e) => setTaskInput(e.target.value)}
        />
        <select
          className='selector'
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
        >
          <option value='BackLog'>Backlog</option>
          <option value='InProgress'>In Progress</option>
          <option value='Completed'>Completed</option>
        </select>
        <button className='btn-add' onClick={handleAddTask}>Add</button>
      </div>
      <div>
        {Object.entries(tasks).map(([category, categoryTasks]) => (
          <div key={category}>
            <h2>{category}</h2>
            <hr/>
            {categoryTasks.map((task, index) => (
              <div key={index}>
                <p>{task}</p>
                <button onClick={() => handleDeleteTask(category, index)}>Delete</button>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
